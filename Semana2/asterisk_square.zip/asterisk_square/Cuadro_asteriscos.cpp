#include <iostream>
using namespace std;

int main()
{
    //Escriba un programa que lea un número entero y a partir de este, cree un cuadro de asteriscos con ese
    //  tamaño.Los asteriscos son para dibujar los lados del cuadro.
    int L;

    cout << "Insert the lenght of the square side: ";
    cin >> L;

    string matriz[100][100];

    for (int fila = 0; fila <= L - 1; fila++) {
        for (int columna = 0; columna <= L - 1; columna++) {
            if (fila == 0) {
                matriz[fila][columna] = "* ";
            }
            else if (fila < L - 1) {
                if (columna == 0) {
                    matriz[fila][columna] = "* ";
                }
                else if (columna == L - 1) {
                    matriz[fila][columna] = "* ";
                }
                else {
                    matriz[fila][columna] = "  ";
                }
            }
            else {
                matriz[fila][columna] = "* ";
            }
        }
    }


    for (int fila = 0; fila <= L - 1; fila++) {
        for (int columna = 0; columna <= L - 1; columna++) {
            cout << matriz[fila][columna];
        }
        cout << "\n";
    }


    return 0;
}
