#include <iostream>
#include <cmath>//Math library
using namespace std;

int main()
{
	/* Escriba un programa que reciba tres n�meros e indique el tipo de tri�ngulo que forman
	(isósceles, equil�tero, escaleno�). Comprobar que los n�meros suministrados forman un
	tri�ngulo o no, de no ser as� deben indicarlo mediante un mensaje a la consola.

	Equilatero es el que tiene los tres lados iguales
	Isoseles es el que tiene dos lados iguales
	Escaleno no tiene ningun lado igual

	Formula de Heron (Para �rea del tri�ngulo, en caso de dar error, NO ES UN TRI�NGULO):  sqrt(s(s-a)(s-b)(s-c))
	Donde s es semiperimetro y a,b y c los lados ingresados por el usuario*/
	double la, lb, lc;//Los lados del tri�ngulo

	cout << "Enter the first side of the triangle: ";
	cin >> la;

	cout << "Enter the second side of the triangle: ";
	cin >> lb;

	cout << "Enter the third side of the triangle: ";
	cin >> lc;

	double semip = (la + lb + lc) / 2;

	double area = sqrt(semip * (semip - la) * (semip - lb) * (semip - lc));
	//Se comparan los lados con la finalidad de identificar el tipo de triangulo.
	if (area >= 0) {
		if (la == lb) {
			if (la == lc) {
				cout << "The given information belongs to a equilateral triangle";
			}
			else {
				cout << "The given information belongs to a isoceles triangle";
			}
		}

		else {
			if (la == lc) {
				cout << "The given information belongs to a isoceles triangle ";
			}
			else if (lb == lc) {
				cout << "The given information belongs to a isoceles triangle ";
			}
			else {
				cout << "The given information belongs to a scalene triangle";
			}
		}
	}
	else {
		cout << "The given information doesn't belong to a triangle";
	}


	return 0;
}