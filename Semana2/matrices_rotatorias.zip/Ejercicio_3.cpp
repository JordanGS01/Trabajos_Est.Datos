#include <iostream>
using namespace std;
void imprimir_matriz(int matrix[5][5]) {
    for (int x = 0; x <= 4; x++) {
        for (int y = 0; y <= 4; y++) {
            cout << matrix[x][y] << " ";
        }
        cout << "\n";
    }
}

void rotar(int matr[5][5], int rotaciones, int coor_x, int coor_y) {
    int counter = 0;
    int mat_ret[5][5];
    int num = 4;
    while(counter != rotaciones){
        num = 4;
        for (int i = 0; i <= 4; i++) {
            for (int j = 0; j <= 4; j++) {
                mat_ret[j][num] = matr[i][j];
            }
            num = num - 1;
        }
        counter = counter + 1;
        for (int a = 0; a <= 4; a++) {
            for (int b = 0; b <= 4;b++) {
                matr[a][b] = mat_ret[a][b];
            }
        }
    }
    imprimir_matriz(mat_ret);
    cout << endl;
    cout << mat_ret[coor_x][coor_y];
    }

int main() {
    int mat[5][5] = { {1,2,3,4,5} ,{6,7,8,9,10},{11,12,13,14,15},{16,17,18,19,20},{21,22,23,24,25} };
    int num_buscado;
    int coordenada_y;
    int coordenada_x;
    imprimir_matriz(mat);

    cout << "\n";
    cout << "digite un numero de la matriz";
    cin >> num_buscado;

    for (int x = 0; x <= 4; x++) {
        for (int y = 0; y <= 4; y++) {
            if (mat[x][y] == num_buscado) {
                coordenada_x = x;
                coordenada_y = y;
            }
        }
    }
    

    rotar(mat,3,coordenada_x,coordenada_y);
    return 0;
}